# ScrapySeleniumTest

Scrapy Selenium on Taobao Product